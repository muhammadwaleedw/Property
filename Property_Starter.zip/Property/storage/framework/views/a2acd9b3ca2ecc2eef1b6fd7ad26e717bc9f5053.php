<div class="sidebar" data-color="white" data-active-color="danger">
    <div class="logo">
        
        <a href="http://www.digitaldesignunit.com" class="simple-text logo-normal">
            <?php echo e(__('Digital Design Unit')); ?>

        </a>
    </div>
    <div class="sidebar-wrapper">
        <ul class="nav">
            <li class="<?php echo e($elementActive == 'dashboard' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('page.index', 'dashboard')); ?>">
                    <i class="nc-icon nc-bank"></i>
                    <p><?php echo e(__('Dashboard')); ?></p>
                </a>
            </li>
            <li class="<?php echo e($elementActive == 'user' || $elementActive == 'profile' ? 'active' : ''); ?>">
                <a data-toggle="collapse" aria-expanded="true" href="#laravelExamples">
                    <i class="nc-icon"><img src="<?php echo e(asset('paper/img/laravel.svg')); ?>"></i>
                    <p>
                            <?php echo e(__('Laravel examples')); ?>

                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse show" id="laravelExamples">
                    <ul class="nav">
                        <li class="<?php echo e($elementActive == 'profile' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('profile.edit')); ?>">
                                <span class="sidebar-mini-icon"><?php echo e(__('UP')); ?></span>
                                <span class="sidebar-normal"><?php echo e(__(' User Profile ')); ?></span>
                            </a>
                        </li>
                        <li class="<?php echo e($elementActive == 'user' ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('page.index', 'user')); ?>">
                                <span class="sidebar-mini-icon"><?php echo e(__('U')); ?></span>
                                <span class="sidebar-normal"><?php echo e(__(' User Management ')); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="<?php echo e($elementActive == 'icons' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('page.index', 'icons')); ?>">
                    <i class="nc-icon nc-diamond"></i>
                    <p><?php echo e(__('Icons')); ?></p>
                </a>
            </li>
            <li class="<?php echo e($elementActive == 'map' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('page.index', 'map')); ?>">
                    <i class="nc-icon nc-pin-3"></i>
                    <p><?php echo e(__('Maps')); ?></p>
                </a>
            </li>
            <li class="<?php echo e($elementActive == 'notifications' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('page.index', 'notifications')); ?>">
                    <i class="nc-icon nc-bell-55"></i>
                    <p><?php echo e(__('Notifications')); ?></p>
                </a>
            </li>
            <li class="<?php echo e($elementActive == 'tables' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('page.index', 'tables')); ?>">
                    <i class="nc-icon nc-tile-56"></i>
                    <p><?php echo e(__('Table List')); ?></p>
                </a>
            </li>
            <li class="<?php echo e($elementActive == 'typography' ? 'active' : ''); ?>">
                <a href="<?php echo e(route('page.index', 'typography')); ?>">
                    <i class="nc-icon nc-caps-small"></i>
                    <p><?php echo e(__('Typography')); ?></p>
                </a>
            </li>
            <li class="active-pro <?php echo e($elementActive == 'upgrade' ? 'active' : ''); ?>"></li>
        </ul>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Property\Property\resources\views/layouts/navbars/auth.blade.php ENDPATH**/ ?>